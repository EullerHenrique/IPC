/**
 * @file exemplo6.c
 * @brief Exibe a representação binária interna de um número short int
 *        e dos caracteres A e B.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

void bin(unsigned short n, unsigned short numbits)
{
  unsigned short i;
  for (i = 1 << (numbits - 1); i > 0; i >>= 1)
    (n & i)? printf("1") : printf("0");

  return;
} // bin

int main(void){

  printf("Representação binária de %d\n", 16706);
  bin(16706, 16);
  printf("\n");
  
  printf("Representação binária de %c\n", 'B');
  bin('B', 8);
  printf("\n");
  
  printf("Representação binária de %c\n", 'A');
  bin('A', 8);
  printf("\n");

  return 0;
} // main

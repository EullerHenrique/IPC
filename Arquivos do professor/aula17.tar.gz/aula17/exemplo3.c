/**
 * @file exemplo3.c
 * @brief Cria uma estrutura, lê as informações do teclado e depois passa a 
 *        estrutura para uma função que mostrará as informações lidas.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
   char nome[30];
   int  nota[3];
   int  final;
} Estudante;


void imprimeEstudante(Estudante estudante){
  printf("\nNome: %s\n", estudante.nome);

  for(int i = 0; i < 3; i++)
    printf("Nota %d: %d\n", i+1, estudante.nota[i]);
  printf("Nota na prova final: %d\n", estudante.final);
  
  return;
} // imprimeEstudante


int main(void){
  Estudante estudante;

  printf("Digite o nome do estudante: ");
  if (fgets(estudante.nome, sizeof(estudante.nome), stdin) == NULL){
      fprintf(stderr, "Erro ao ler o nome\n");
      exit(1);
    } else {
      // retira o \n do final da string lida
      estudante.nome[strcspn(estudante.nome, "\n")] = 0;
    }

  printf("Digite as 3 notas: ");
  scanf("%d %d %d", &estudante.nota[0], &estudante.nota[1],
        &estudante.nota[2]);

  printf("Digite a nota da prova final: ");
  scanf("%d", &estudante.final);

  imprimeEstudante(estudante);

  return 0;
} // main

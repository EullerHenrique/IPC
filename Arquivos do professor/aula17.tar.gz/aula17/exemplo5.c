/**
 * @file exemplo5.c
 * @brief Demonstra o uso de união para imprimir uma variável, primeiro
 *        como um número e depois como dois caracteres.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

typedef union
{
  short num;
  char vetC[2];
} CompartilhaDados;

int main(void){
  CompartilhaDados dados;

  dados.num = 16706;

  printf("Short: %hd\n", dados.num);
  printf("vetC[0]: %c\n", dados.vetC[0]);
  printf("vetC[1]: %c\n", dados.vetC[1]);
  
  return 0;
} // main

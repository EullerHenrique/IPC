/**
 * @file exemplo7.c
 * @brief Cria um menu de opções, lê um inteiro e executa a função
 *        matemática escolhida sobre o inteiro lido.
 *
 * As funções matemáticas implementadas são:
 * 1 - fatorial
 * 2 - número de Fibonacci
 *
 * @author Alexsandro Santos Soares
 * @date 30/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

#define OPCAO_MINIMA 1
#define OPCAO_MAXIMA 4
#define SAIR OPCAO_MAXIMA

/**
 * @brief Calcula o fatorial de um número inteiro
 *
 * @param num inteiro longo sem sinal
 * @return fatorial de num
 */
unsigned long fatorial(unsigned long num){
    unsigned long int i = 0;   // contador de iterações
    unsigned long int fat = 0; // acumula o valor do fatorial

    i = 0;
    fat = 1;
    while (i < num) {
        i = i + 1;
        fat = fat * i;
    } // while

    return fat;
} // fatorial

/**
 * @brief Calcula o n-ésimo número de Fibonacci. O primeiro número
 *        está na posição 0.
 *
 * @param n inteiro longo sem sinal
 * @return n-ésimo número de Fibonacci.
 */
unsigned long fibonacci(unsigned long n){
    unsigned long int f1 = 0;    // o penúltimo número de Fibonacci calculado.
    unsigned long int f2 = 0;    // o último número de Fibonacci calculado.
    unsigned long int temp = 0;  // temporário para guardar a soma.
    unsigned long int i = 0;     // contador de iterações

    if (n == 0 || n == 1){
        return n;
    } else {
        f1 = 0;
        f2 = 1;
        temp = 0;
        i = 2;
        while (i <= n) {
            temp = f1 + f2;
            f1 = f2;
            f2 = temp;
            i = i + 1;
        } // while

        return f2;
    } // else
} // fibonacci

/**
 * @brief Exibe as opções do menu
 *
 */
void exibirOpcoes(void){
    printf("\nOpções:\n\n");
    printf("1 - fatorial\n");
    printf("2 - n-ésimo número de Fibonacci\n");
    printf("3 - ler um novo inteiro\n");
    printf("4 - sair\n");
    printf("\n");
} // exibirOpcoes

/**
 * @brief Lê uma opção válida informada pelo usuário
 * 
 * @return um inteiro representando a opção escolhida
 */
int lerOpcao(void){
    int opcao = 0;

    printf("Digite uma opção: ");
    scanf("%d", &opcao);
    while ( !(OPCAO_MINIMA <= opcao && opcao <= OPCAO_MAXIMA) ){
        printf("Opção inválida!\n\n");
        printf("Digite uma opção: ");
        scanf("%d", &opcao);
    } // while

    return opcao;
} // lerOpcao

/**
 * @brief Imprime o texto mostrando o resultado da operação 
 *        escolhida
 *
 * @param opcao número da opção escolhida
 * @param num número sobre o qual a operação foi realizada
 * @param resultado resultado da operação sobre num
 */
void imprimirResultado(int opcao, long int num, long int resultado){
    printf("\n");
    printf("--------------------------------------------------\n");
    if (opcao == 1){
        printf("Fatorial de %lu = %lu\n", num, resultado);
    } else if (opcao == 2){
        printf("%lu-ésimo número de Fibonacci = %lu\n", num, resultado);
    } else if (opcao == 3){
        printf("Novo inteiro lido = %lu\n", num);
    } else {
        printf("Fim.\n");
    }

    printf("--------------------------------------------------\n");

    return;
} // imprimirResultado

/**
 * @brief Exibe o lista de opções, executa a operação selecionada e
 *        exibe o resultado.
 *
 * @param num valor inicial lido do usuário
 */
void menu(unsigned long num){
    int opcao = 0;
    unsigned long resultado = 0;

    while (opcao != SAIR){
        exibirOpcoes();
        opcao = lerOpcao();

        if (opcao == 1){
            resultado = fatorial(num);
        } else if (opcao == 2){
            resultado = fibonacci(num);
        } else if (opcao == 3){
            printf("Digite um inteiro: ");
            scanf("%lu", &num);
        } else {
        } // else

        imprimirResultado(opcao, num, resultado);
    } // while

    return;
} // menu


int main(void){
    unsigned long int numero = 0;

    printf("Digite um inteiro: ");
    scanf("%lu", &numero);
    menu(numero);

    return 0;
} // main

/**
 * @file exemplo2.c
 * @brief Demonstra o fato de que uma função pode ser chamada várias vezes
 *
 * @author Alexsandro Santos Soares
 * @date 30/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

/**
 * @brief Imprime um inteiro na saída padrão.
 *
 * @param x número inteiro a ser impresso
 */
void imprimeInteiro(int x){
    printf("%d\n", x);
    return;
} // imprimeInteiro

int main(void){
    int a = 0;

    a = 5;
    imprimeInteiro(a);

    a = 33;
    imprimeInteiro(a);
    
    return 0;
} // main

/**
 * @file exemplo6.c
 * @brief Lê um número inteiro longo com no máximo 6 dígitos e o imprime 
 *        com um espaço separando os três últimos dígitos.
 *
 * O número será impresso com zeros à esquerda caso seja menor que 100 000.
 *
 * @author Alexsandro Santos Soares
 * @date 30/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

/**
 * @brief Separa um número inteiro em dois números, o último deles 
 *        contendo apenas três dígitos e imprime ambos separados por 
 *        espaço.
 *
 * @param num número inteiro
 */
void imprimeComEspaco(long num){
    int milhares = 0;
    int centenas = 0;

    milhares = num / 1000;
    centenas = num % 1000;

    printf("O número digitado é \t%03d %03d\n", milhares, centenas);
    return;
} // imprimeComEspaco


int main(void){
    long int numero = 0;

    printf("Digite um inteiro com até 6 dígitos: ");
    scanf("%ld", &numero);
    imprimeComEspaco(numero);

    return 0;
} // main

/**
 * @file exemplo1.c
 * @brief Demonstra o uso de funções ao chamar uma pequena função para
 *        multiplicar dois números.
 *
 *
 * @author Alexsandro Santos Soares
 * @date 30/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

/**
 * @brief Multiplica dois números e retorna o produto.
 *
 * @param x primeiro número
 * @param y segundo número
 * @return O produto de x por y
 */
int multiplica(int x, int y){
    return x * y;
} // multiplica

int main(void){
    int multiplicador = 0;
    int multiplicando = 0;
    int produto = 0;

    printf("Digite dois inteiros: ");
    scanf("%d%d", &multiplicador, &multiplicando);
    produto = multiplica(multiplicador, multiplicando);
    printf("O produto de %d por %d é %d\n",
           multiplicador, multiplicando, produto);  
    return 0;
} // main

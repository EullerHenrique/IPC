/**
 * @file exemplo5.c
 * @brief Lê um número inteiro e imprime seu dígito menos significativo.
 *
 * @author Alexsandro Santos Soares
 * @date 30/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

/**
 * @brief Extrai o dígito menos significativo de um inteiro.
 *
 * @param num número inteiro
 * @return dígito menos significativo
 */
int primeiroDigito(int num){
    return (num % 10);
} // primeiroDigito


/**
 * @brief Extrai o segundo dígito menos significativo de um inteiro.
 *
 * @param num número inteiro
 * @return segundo dígito menos significativo
 */
int segundoDigito(int num){
    int resultado = 0;

    resultado = (num / 10) % 10;
    return resultado;
} // segundoDigito

/**
 * @brief Soma os dois primeiros dígitos menos significativos de 
 *        um inteiro.
 *
 * @param num número inteiro
 * @return a soma dos dois  primeiros dígitos menos significativos num.
 */
int somaDoisDigitos(int num){
    int resultado = 0;

    resultado = primeiroDigito(num) + segundoDigito(num);
    return resultado;
} // somaDoisDigitos


int main(void){
    int numero = 0;
    int soma = 0;

    printf("Digite um inteiro: ");
    scanf("%d", &numero);

    soma = somaDoisDigitos(numero);
    printf("A soma dos dois dígitos menos significativos é: %d\n", soma);

    return 0;
} // main

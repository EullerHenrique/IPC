/**
 * @file exemplo3.c
 * @brief Lê um número inteiro e imprime o quadrado dele.
 *
 * @author Alexsandro Santos Soares
 * @date 30/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

/**
 * @brief Lê um número inteiro da entrada padrão
 *
 * @return número lido
 */
int leiaNum(void){
   int x;

   printf("Digite a quantidade: ");
   scanf("%d", &x);
   return x;
} // leiaNum


/**
 * @brief Calcula o quadrado de um número
 *
 * @param x número 
 * @return o quadrado de x
 */
int quadrado(int x){
   return x * x;
} // quadrado


/**
 * @brief Imprime um inteiro na saída padrão.
 *
 * @param x número inteiro a ser impresso
 */
void imprimeInteiro(int x){
    printf("%d\n", x);
    return;
} // imprimeInteiro


int main(void){
    int a = 0;
    int b = 0;

    a = leiaNum();
    b = quadrado(a);
    imprimeInteiro(b);

    return 0;
} // main

/**
 * @file exemplo10.c
 * @brief Calcula o quociente e o resto de dois números inteiros.
 *
 *    O programa lê dois inteiros e depois imprime o quociente e
 * o resto do primeiro número dividido pelo segundo.
 * peso ideal usando as fórmulas de Hammond.
 *
 * @author Alexsandro Santos Soares
 * @date 01/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

/**
 * @brief Divide dois inteiros e calcula o quociente e o resto.
 *
 *    Esta função divide dois inteiros e coloca o quociente e o
 * resto nas variáveis da função chamadora.
 *
 * @param dividendo número inteiro
 * @param divisor número inteiro
 * @param aquoc endereço da variável onde o quociente será colocado
 * @param aresto endereço da variável onde o resto será colocado
 */
void divide(int dividendo, int divisor, int* aquoc, int* aresto){
    *aquoc  = dividendo / divisor;
    *aresto = dividendo % divisor;

    return;
} // divide

/**
 * @brief Lê dois número inteiros do teclado
 *
 *    Esta função lê dois números inteiros do teclado e
 * os armazena nas variáveis especificadas na lista de parâmetros.
 *
 * @param adividendo endereço da variável onde o dividendo será colocado
 * @param adivisor endereço da variável onde o divisor será colocado
 */
void obtemDados(int* adividendo, int* adivisor){
    printf("Digite dois inteiros e pressione enter: ");
    scanf("%d%d", adividendo, adivisor);
    return;
} // obtemDados

/**
 * @brief Imprime o quociente e o resto.
 *
 * @param quoc quociente da divisão
 * @param resto resto da divisão
 */
void imprime(int quoc, int resto){
    printf("Quociente: %3d\n", quoc);
    printf("Resto: %3d\n", resto);
    return;
} // imprime


int main(void){
    int dividendo=0;
    int divisor=0;
    int quoc=0;
    int resto=0;

    obtemDados(&dividendo, &divisor);
    divide(dividendo, divisor, &quoc, &resto);
    imprime(quoc, resto);

    return 0;
} // main

/**
 * @file exemplo4.c
 * @brief Lê um número inteiro e imprime seu dígito menos significativo.
 *
 * @author Alexsandro Santos Soares
 * @date 30/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

/**
 * @brief Extrai o dígito menos significativo de um inteiro.
 *
 * @param num número inteiro
 * @return dígito menos significativo
 */
int primeiroDigito(int num){
    return (num % 10);
} // primeiroDigito

int main(void){
    int numero = 0;
    int digito = 0;

    printf("Digite um inteiro: ");
    scanf("%d", &numero);

    digito = primeiroDigito(numero);
    printf("\nO dígito menos significativo é: %d\n", digito);

    return 0;
} // main

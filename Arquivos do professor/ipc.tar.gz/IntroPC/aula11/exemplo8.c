#include <stdio.h>

void troca(int* ax, int* ay){
    int temp;

    temp = *ax; 
    *ax  = *ay; 
    *ay  = temp;
    return;
} // troca

int main(void){
    int a;
    int b;

    a = 5;
    b = 10;
    printf("a = %d b = %d\n", a, b);

    troca(&a, &b);
    printf("a = %d b = %d\n", a, b);
    
    return 0;
} // main

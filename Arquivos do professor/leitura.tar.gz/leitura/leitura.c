#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NOME_MAX 40
#define PERS_MAX 20

typedef struct
{
  char nome[NOME_MAX];
  int idade;
} Personagem;

int main(void){
  char arquivo[] = "personagens.txt"; // nome do arquivo com os personagens
  FILE *fp = NULL;
  Personagem personagem[PERS_MAX]; // guarda os personagens lidos
  
  int i = 0; // número de personagens lidos
  char buf[NOME_MAX] = {'\0'}; // temporário para o nome

  fp = fopen(arquivo, "r"); // abre o arquivo texto em modo de leitura

  if (fp == NULL){
    fprintf(stderr, "Erro ao abrir o arquivo %s.\n", arquivo);
    exit(1);
  } else
    printf("\nArquivo %s aberto.\n", arquivo);

  i = 0;
  while( !feof(fp) &&   // feof testa se chegou no final do arquivo.
	 i < PERS_MAX)  // Não ultrapasse o tamanho máximo do arranjo.
    {
      memset(buf, '\0', sizeof(buf)); // Zera o buffer.

      // Lê o nome para a string temporária buf.
      if (fgets(buf, sizeof(buf), fp) == NULL){
	fprintf(stderr, "Erro ao ler o nome.\n");
	exit(1);
      } else {
	// Retira o \n do final da string lida.
	buf[strcspn(buf, "\n")] = '\0';

	// Copia de buf para o campo nome do i-esimo personagem
	strcpy(personagem[i].nome, buf);
      }

      // Lê o inteiro juntamente com \n.
      fscanf(fp, "%d\n", &personagem[i].idade);
      // incrementa o contador pois mais um personagem foi lido
      ++i;    
    }

  fclose(fp);
  printf("Arquivo %s fechado.\n", arquivo);

  printf("\nLidos %d personagens.\n\n", i);
  for(int j = 0; j < i; j++){
    printf("Personagem %d:\n", j);
    printf("Nome:  %s\n", personagem[j].nome);
    printf("Idade: %d\n\n", personagem[j].idade);
  } // for j

  return 0;
} // main

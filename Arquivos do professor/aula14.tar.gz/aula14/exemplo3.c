/**
 * @file exemplo3.c
 * @brief Preenche a diagonal principal de uma matriz quadrada com 0,
 *        a triângulo inferior dela com -1 e o superior com +1.
 *
 * @author Alexsandro Santos Soares
 * @date 1/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

#define ORDEM 6

int main(void){
  int matriz[ORDEM][ORDEM];

  for(int linha = 0; linha < ORDEM; linha++)
    for(int coluna = 0; coluna < ORDEM; coluna++)
      if (linha == coluna)
         matriz[linha][coluna] = 0;
      else if (linha > coluna)
         matriz[linha][coluna] = -1;
      else
         matriz[linha][coluna] = 1;

  for(int linha = 0; linha < 6; linha++){
     for(int coluna = 0; coluna < 6; coluna++)
        printf("%3d", matriz[linha][coluna]);
     printf("\n");
  } // for linha
  
  return 0;
} // main

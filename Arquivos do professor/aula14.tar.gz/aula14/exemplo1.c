/**
 * @file exemplo1.c
 * @brief Transforma um arranjo bidimensional em um arranjo unidimensional
 *        correspondente.
 *
 * @author Alexsandro Santos Soares
 * @date 1/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

#define LINHAS  2
#define COLUNAS 5

int main(void){
  int matriz[LINHAS][COLUNAS] =
    {{ 0,  1,  2,  3 , 4},
     {10, 11, 12, 13, 14}};
  int vet[LINHAS * COLUNAS];

  for(int linha = 0; linha < LINHAS; linha++)
    for(int coluna = 0; coluna < COLUNAS; coluna++)
      vet[linha * COLUNAS + coluna] = matriz[linha][coluna];

  for(int linha = 0; linha < LINHAS * COLUNAS; linha++)
    printf(" %02d ", vet[linha]);
  printf("\n");
  return 0;
} // main

/**
 * @file exemplo3.c
 * @brief Calcula a média aritmética dos elementos de um arranjo
 *        com tamanho variável
 *
 * @author Alexsandro Santos Soares
 * @date 1/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

// Protótipo da função
double media_aritmetica(int tamanho, int vet[*]);

int main(void){
  int tamanho=0;
  double media=0.0;

  printf("Quantos números devo ler? ");
  scanf("%d", &tamanho);

  // Cria e preenche um arranjo de tamanho variável
  {
    int numeros[tamanho];

    // Preenche o arranjo
    for(int i = 0; i < tamanho; i++){
      printf("Digite o número %2d: ", i + 1);
      scanf("%d", &numeros[i]);
    } // for
    media = media_aritmetica(tamanho, numeros);
  } // Bloco para preecher o arranjo
  
  printf("A média é %lf\n", media);

  return 0;
} // main

/**
 * @brief Calcula a média aritmética dos elementos de um arranjo
 *
 * @param vet um vetor contendo números inteiros
 * @return a média aritmética
 */
double media_aritmetica(int tamanho, int vet[tamanho]){
  int soma = 0;

  for(int i = 0; i < tamanho; i++)
    soma += vet[i];

  return ((double) soma / tamanho);
} // media_aritmetica

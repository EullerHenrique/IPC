/**
 * @file exemplo2.c
 * @brief Calcula a média aritmética dos elementos de um arranjo
 *
 * @author Alexsandro Santos Soares
 * @date 1/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

#define TAM_MAX 5

// Protótipo da função
double media_aritmetica(int vet[]);

int main(void){
  double media=0.0;
  int numeros[TAM_MAX]={3, 7, 2, 4, 5};

  media = media_aritmetica(numeros);
  printf("A média é %lf\n", media);

  return 0;
} // main

/**
 * @brief Calcula a média aritmética dos elementos de um arranjo
 *
 * @param vet um vetor contendo números inteiros
 * @return a média aritmética
 */
double media_aritmetica(int vet[]){
  int soma = 0;

  for(int i = 0; i < TAM_MAX; i++)
    soma += vet[i];

  return (soma / (double) TAM_MAX);
} // media_aritmetica

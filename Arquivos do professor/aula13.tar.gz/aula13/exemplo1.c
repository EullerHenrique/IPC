/**
 * @file exemplo1.c
 * @brief Lê uma sequência de com no máximo 50 números e a escreve
 *        revertida.
 *
 * @author Alexsandro Santos Soares
 * @date 1/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

#define TAM_MAX 50

int main(void){
  int numMax=0; // Número máximo de inteiros ler na sequência
  int numeros[TAM_MAX]={0};

  printf("Você pode entrar com até 50 inteiros.\n");
  printf("Quantos inteiros você quer entrar? ");
  scanf("%d", &numMax);

  if (numMax > TAM_MAX)
    numMax = TAM_MAX;    // limita ao tamanho do arranjo

  // Preenche o arranjo
  printf("\nDigite seus números: \n");
  for(int i = 0; i < numMax; i++)
    scanf("%d", &numeros[i]);

  // Imprime o arranjo
  printf("\nSeus números revertidos são: \n");
  for(int i = numMax - 1, numImpressos = 0;
      i >= 0;
      i--){
    printf("%3d", numeros[i]);
    if (numImpressos < 9)
      numImpressos++;
    else {
      printf("\n");
      numImpressos = 0;
    } // else
  } // for
  printf("\n");

  return 0;
} // main

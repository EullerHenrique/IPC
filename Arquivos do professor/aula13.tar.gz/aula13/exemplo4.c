/**
 * @file exemplo4.c
 * @brief Multiplica os elementos de um arranjo por 2
 *
 * @author Alexsandro Santos Soares
 * @date 1/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

#define TAM_MAX 5

// Protótipo da função
void multiplica2(int vet[]);

int main(void){
  int numeros[TAM_MAX]={3, 7, 2, 4, 5};

  multiplica2(numeros);

  printf("O arranjo agora contém: ");
  for(int i = 0; i < 5; i++)
    printf("%3d", numeros[i]);
  printf("\n");

  return 0;
} // main

/**
 * @brief Multiplica cada elemento de um arranjo por 2
 *
 * @param vet um vetor contendo números inteiros
 */
void multiplica2(int vet[]){

  for(int i = 0; i < TAM_MAX; i++)
     vet[i] *= 2;

  return;
} // multiplica2

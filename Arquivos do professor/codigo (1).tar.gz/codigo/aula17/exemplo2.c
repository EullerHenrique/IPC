/**
 * @file exemplo2.c
 * @brief Lê duas distãncias expressas em metros e centímetros, as soma
 *        e imprime o resultado. Demonstra o uso de estruturas.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

typedef struct
{
  int metro;
  int centimetro;
} Medida;

int main(void){
  Medida dist1;
  Medida dist2;
  Medida soma;

  printf("Primeira distância\n");

  // Entrada do campo metro para a variável estrutura dist1
  printf("Digite a quantidade de metros: ");
  scanf("%d", &dist1.metro);
  
  // Entrada do campo centimetro para a variável estrutura dist1
  printf("Digite a quantidade de centímetros: ");
  scanf("%d", &dist1.centimetro);

  printf("Segunda distância\n");

  // Entrada do campo metro para a variável estrutura dist2
  printf("Digite a quantidade de metros: ");
  scanf("%d", &dist2.metro);
  
  // Entrada do campo centimetro para a variável estrutura dist2
  printf("Digite a quantidade de centímetros: ");
  scanf("%d", &dist2.centimetro);

  soma.metro = dist1.metro + dist2.metro;
  soma.centimetro = dist1.centimetro + dist2.centimetro;

  if (soma.centimetro > 99){
    ++soma.metro;
    soma.centimetro -= 100;
  }

  printf("Soma das distâncias: %d m %d cm\n", soma.metro, soma.centimetro);
  
  return 0;
} // main

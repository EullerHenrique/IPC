/**
 * @file exemplo9.c
 * @brief Somente um campo pode ser acessado por vez em uma união.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

typedef union
{
  char  nome[32];
  float salario;
  int   cpf;
} UniaoTrab;


int main(void){
  UniaoTrab trab;

  printf("Digite o nome:\n");
  scanf("%s", trab.nome);

  printf("Digite o salário:\n");
  scanf("%f", &trab.salario);

  printf("\nMostrando\n");
  printf("Nome: %s\n", trab.nome);
  printf("Salário: %.1f\n", trab.salario);
  
  return 0;
} // main

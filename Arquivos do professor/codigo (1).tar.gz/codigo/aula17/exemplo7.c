/**
 * @file exemplo7.c
 * @brief Demonstra o uso de união encaixada como um membro de uma estrutura
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <string.h>

typedef struct
{
   char prenome[20];
   char inicial;
   char sobrenome[30];
} Pessoa;

typedef struct
{
  char tipo;
  union
  {
     char empresa[40];
     Pessoa pessoa;
  } un;
} Entrada;


int main(void){
  Entrada negocio = {'E', "Empresa ABC"};
  Entrada amigo;
  Entrada agenda[2];

  amigo.tipo = 'P';
  strcpy(amigo.un.pessoa.prenome, "Marta");
  strcpy(amigo.un.pessoa.sobrenome, "Silva");
  amigo.un.pessoa.inicial = 'A';

  agenda[0] = negocio;
  agenda[1] = amigo;

  for(int i = 0; i < 2; i++)
    switch (agenda[i].tipo){
    case 'E': printf("Empresa: %s\n", agenda[i].un.empresa);
              break;
    case 'P': printf("Amigo:   %s %c. %s\n",
		     agenda[i].un.pessoa.prenome,
		     agenda[i].un.pessoa.inicial,
		     agenda[i].un.pessoa.sobrenome);
              break;
    default: printf("Erro no tipo\n"); break;
    } // switch

  return 0;
} // main

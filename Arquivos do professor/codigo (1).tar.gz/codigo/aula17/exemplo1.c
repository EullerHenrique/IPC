/**
 * @file exemplo1.c
 * @brief Demonstra o uso do tipo enumerado.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
  enum efeitos { NEGRITO = 1,
		 ITALICO = 2,
		 SUBLINHADO = 4};
  int meusEfeitos = 0;

  meusEfeitos = NEGRITO | SUBLINHADO;
  
  //    00000001
  //  | 00000100
  //  ------------
  //    00000101

  printf("%d\n\n", meusEfeitos);
  if (meusEfeitos & NEGRITO)
    printf("Negrito\n");

  if (meusEfeitos & ITALICO)
    printf("Itálico\n");
  else
    printf("Não há itálico.\n");

  if (meusEfeitos & SUBLINHADO)
    printf("Sublinhado\n");
  return 0;
} // main

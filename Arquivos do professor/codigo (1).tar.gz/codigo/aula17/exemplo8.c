/**
 * @file exemplo8.c
 * @brief Diferença entre os espaços ocupados por uma união e por uma estrutura.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

typedef union
{
  char nome[32];
  float salario;
  int cpf;
} UniaoTrab;

typedef struct
{
  char nome[32];
  float salario;
  int cpf;
} StructTrab;


int main(void){

  printf("espaço ocupado pela união:     %5zu bytes\n", sizeof(UniaoTrab));
  printf("espaço ocupado pela estrutura: %5zu bytes\n", sizeof(StructTrab));
  
  return 0;
} // main

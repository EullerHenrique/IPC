/**
 * @file exemplo10.c
 * @brief Escreve todos os elementos de um arranjo de inteiros para um
 *        arquivo, lendo-o de volta e imprimindo na tela.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <stdlib.h>

#define TAM_MAX 6

int main(void){
  int vet[TAM_MAX] = {0};  // arranjo original
  int vet2[TAM_MAX] = {0}; // conterá a cópia de vet lida do arquivo
  int i = 0;
  FILE *fp;
  
  fp = fopen("arranjo.dat", "wb"); // escrita em modo binário
  
  if (fp == NULL){
     fprintf(stderr, "Erro ao abrir o arquivo\n");
     exit(1);
  }

  // Lendo o arranjo do teclado
  printf("\nDigite %d inteiros:\n", TAM_MAX);
  for(i = 0; i < TAM_MAX; ++i){
    scanf("%d", &vet[i]);
  } // for

  // Escrevendo o arranjo todo para o arquivo
  fwrite(vet, sizeof(vet), 1, fp);
  fclose(fp); // fechando o arquivo

  fp = fopen("arranjo.dat", "rb"); // leitura em modo binário

  // Lendo o arranjo todo do arquivo
  fread(vet2, sizeof(vet2), 1, fp);
  fclose(fp);

  printf("\nArranjo lido:\n");
  for(i = 0; i < TAM_MAX; ++i)
    printf("%d: %d\n", i, vet2[i]);
  
  return 0;
} // main

/**
 * @file exemplo7.c
 * @brief Lê uma uma linha inteira de texto usando gets_s e a imprime
 *        na tela.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <stdlib.h>

int main(void){
  char nome[30] = {'\0'};

  printf("Digite o nome: ");
  if (fgets(nome, sizeof(nome), stdin) == NULL){
     fprintf(stderr, "Erro ao ler a string\n");
     exit(1);
  }

  printf("O nome digitado foi %s.\n", nome);

  return 0;
} // main

/**
 * @file exemplo1.c
 * @brief Lê um número do teclado e o armazena em um arquivo texto.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <stdlib.h>

int main(void){
  int num;
  FILE *fp;

  fp = fopen("programa.txt", "w"); // abre para escrita

  if (fp == NULL){
    fprintf(stderr, "Erro de escrita no arquivo programa.txt\n");
    exit(1);
  }

  printf("Digite um número: ");
  scanf("%d", &num);

  fprintf(fp, "%d", num);
  fclose(fp);
  
  return 0;
} // main

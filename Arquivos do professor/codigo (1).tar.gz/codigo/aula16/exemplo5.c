/**
 * @file exemplo5.c
 * @brief Lê uma string do teclado e a imprime na tela.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
  char nome[20];

  printf("Digite o nome: ");
  scanf("%s", nome);

  printf("O nome digitado foi %s.\n", nome);

  return 0;
} // main

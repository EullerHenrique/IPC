/**
 * @file exemplo8.c
 * @brief Lê os nomes e as notas de n estudantes do teclado e guarda em
 *        em arquivo.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void){
  char nome[50] = {'\0'};
  int nota = 0;
  int n = 0;

  printf("Digite o número de estudantes: ");
  scanf("%d", &n);
  getchar(); // necessário para consumir o enter
  
  FILE *fp;
  fp = fopen("estudante.txt", "w");
  
  if (fp == NULL){
     fprintf(stderr, "Erro ao abrir o arquivo\n");
     exit(1);
  }

  for(int i = 0; i < n; ++i){
    printf("Para o estudante %d\n", i+1);
    printf("Digite o nome: ");
    if (fgets(nome, sizeof(nome), stdin) == NULL){
      fprintf(stderr, "Erro ao ler o nome\n");
      exit(1);
    } else {
      // retira o \n do final da string lida
      nome[strcspn(nome, "\n")] = 0;
    } // else

    printf("Digite a nota: ");
    scanf("%d", &nota);
    getchar(); // necessário para consumir o enter

    fprintf(fp, "\nNome: %s \nNota=%d \n", nome, nota);
  } // for

  fclose(fp);
  return 0;
} // main

/**
 * @file exemplo2.c
 * @brief Ordena um arranjo em ordem crescente usando o método da inserção.
 *
 * @author Alexsandro Santos Soares
 * @date 6/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

/**
 * @brief Ordena um arranjo em ordem crescente usando o método da inserção.
 *
 *    O arranjo é dividido em duas partes: ordenado e não ordenado. Em cada
 * passo, o primeiro elemento no lado não ordenado é inserido na posição
 * correta no lado ordenado.
 *
 * @param[in/out] a   arranjo com dados a serem ordenados
 * @param[in]     tam número de elementos no arranjo
 *
 * @post O arranjo a estará ordenado do menor para o maior.
 */
void ordenaInsercao(int a[], int tam){
  int i = 0; // índice da posição correta
  int temp = 0;  // temporário usado para realizar a permuta

  for(int j = 1; j < tam; j++){
    // O lado esquerdo a[0..j-1] já está ordenado
    temp = a[j];

    // Procure a posição correta para inserir temp no lado esquerdo,
    // movendo os elementos para a direita, se necessário.
    i = j - 1;
    while (i >= 0 && temp < a[i]){
      a[i+1] = a[i]; // move o elemento uma posição para a direita
      i = i - 1;
    } // while

    a[i+1] = temp; // insira temp na posição correta do lado esquerdo
  } // for j

  return;
}

int main(void){
  int i = 0;
  int a[10] = { 10, 5, 1, 2, 6, 4, 3, 7, 9, 8};

  printf("\nArranjo original:\n");
  for(i = 0; i < 10; i++)
    printf("%d ",a[i]);
  printf("\n");

  ordenaInsercao(a, 10);
  
  printf("Arranjo ordenado:\n");
  for(i = 0; i < 10; i++)
    printf("%d ",a[i]);
  printf("\n");
  
  return 0;
} // main

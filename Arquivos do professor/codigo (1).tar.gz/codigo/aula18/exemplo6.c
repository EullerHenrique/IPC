/**
 * @file exemplo6.c
 * @brief Definição e uso de macros
 *
 * @author Alexsandro Santos Soares
 * @date 6/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

#define PI 3.1415
#define areaCirculo(r) (PI*r*r)

int main(void){
  int raio = 0;
  float area = 0.0;

  printf("\nDigite o raio: ");
  scanf("%d", &raio);

  area = areaCirculo(raio);
  printf("Área = %.2f\n", area);
  
  return 0;
} // main

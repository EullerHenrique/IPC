#ifndef ORDENACAO_H
#define ORDENACAO_H

/**
 * @file ordenacao.h
 * @brief Funções para a ordenação um arranjo em ordem crescente usando
 *        os métodos da seleção e da inserção
 *
 * @author Alexsandro Santos Soares
 * @date 6/05/2018
 * @bugs Nenhum conhecido.
 */


/**
 * @brief Ordena um arranjo selecionando o menor elemento na parte não
 *        ordenada o arranjo e permutando-o com o primeiro elemento no
 *        início da parte não ordenada.
 *
 * @param[in/out] a   arranjo com dados a serem ordenados
 * @param[in]     tam número de elementos no arranjo
 *
 * @post O arranjo a estará ordenado do menor para o maior.
 */
void ordenaSelecao(int a[], int tam);



/**
 * @brief Ordena um arranjo em ordem crescente usando o método da inserção.
 *
 *    O arranjo é dividido em duas partes: ordenado e não ordenado. Em cada
 * passo, o primeiro elemento no lado não ordenado é inserido na posição
 * correta no lado ordenado.
 *
 * @param[in/out] a   arranjo com dados a serem ordenados
 * @param[in]     tam número de elementos no arranjo
 *
 * @post O arranjo a estará ordenado do menor para o maior.
 */
void ordenaInsercao(int a[], int tam);

#endif

/**
 * @file ordenacao.c
 * @brief Funções para a ordenação um arranjo em ordem crescente usando
 *        os métodos da seleção e da inserção
 *
 * @author Alexsandro Santos Soares
 * @date 6/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

#include "ordenacao.h"

/**
 * @brief Ordena um arranjo selecionando o menor elemento na parte não
 *        ordenada o arranjo e permutando-o com o primeiro elemento no
 *        início da parte não ordenada.
 *
 * @param[in/out] a   arranjo com dados a serem ordenados
 * @param[in]     tam número de elementos no arranjo
 *
 * @post O arranjo a estará ordenado do menor para o maior.
 */
void ordenaSelecao(int a[], int tam){
  int imenor = 0; // índice do menor elemento
  int temp = 0;   // temporário usado para realizar a permuta

  for(int i = 0; i < tam; i++){
    // Selecione o menor elemento no lado não ordenado
    imenor = i;
    for(int j = i + 1; j < tam; j++)
      if (a[j] < a[imenor])
         imenor = j;

    // Permute o menor elemento com o primeiro elemento
    // no lado não ordenado.
    temp = a[i];
    a[i] = a[imenor];
    a[imenor] = temp;
  } // for i

  return;
} // ordenaSelecao



/**
 * @brief Ordena um arranjo em ordem crescente usando o método da inserção.
 *
 *    O arranjo é dividido em duas partes: ordenado e não ordenado. Em cada
 * passo, o primeiro elemento no lado não ordenado é inserido na posição
 * correta no lado ordenado.
 *
 * @param[in/out] a   arranjo com dados a serem ordenados
 * @param[in]     tam número de elementos no arranjo
 *
 * @post O arranjo a estará ordenado do menor para o maior.
 */
void ordenaInsercao(int a[], int tam){
  int i = 0; // índice da posição correta
  int temp = 0;  // temporário usado para realizar a permuta

  for(int j = 1; j < tam; j++){
    // O lado esquerdo a[0..j-1] já está ordenado
    temp = a[j];

    // Procure a posição correta para inserir temp no lado esquerdo,
    // movendo os elementos para a direita, se necessário.
    i = j - 1;
    while (i >= 0 && temp < a[i]){
      a[i+1] = a[i]; // move o elemento uma posição para a direita
      i = i - 1;
    } // while

    a[i+1] = temp; // insira temp na posição correta do lado esquerdo
  } // for j

  return;
}

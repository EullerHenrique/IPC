/**
 * @file exemplo8.c
 * @brief Ordena um arranjo e realiza a busca binária.
 *
 * @author Alexsandro Santos Soares
 * @date 6/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <stdbool.h>

#include "busca.h"
#include "ordenacao.h"

int main(void){
  int i = 0;
  int pos = 0;
  int num = 0;
  int a[10] = {10, 8, 6, 4, 5, 3, 7, 9, 2, 1};

  printf("\nArranjo original ordenado:\n");
  for(i = 0; i < 10; i++)
    printf("%d ",a[i]);
  printf("\n");

  ordenaSelecao(a, 10);

  printf("Arranjo ordenado:\n");
  for(i = 0; i < 10; i++)
    printf("%d ",a[i]);
  printf("\n");
  

  printf("\nDigite o número a ser localizado: ");
  scanf("%d", &num);
  if (buscaBinaria(a, 10, num, &pos))
    printf("%d foi encontrado no índice %d\n", num, pos);
  else
    printf("%d não foi encontrado no arranjo\n", num);  
  return 0;
} // main

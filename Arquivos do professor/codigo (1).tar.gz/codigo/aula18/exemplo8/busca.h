#ifndef BUSCA_H
#define BUSCA_H

/**
 * @file busca.h
 * @brief Implementa a busca sequencial em arranjos não ordenados e a busca
 *        binária para arranjos ordenados.
 *
 * @author Alexsandro Santos Soares
 * @date 6/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdbool.h>

/**
 * @brief Localiza um elemento alvo em um arranjo não ordenado.
 *
 * @param[in]  a    arranjo com dados 
 * @param[in]  tam  número de elementos no arranjo
 * @param[in]  alvo elemento procurado
 * @param[out] pPos endereço onde ficará o índice no arranjo do
 *                  elemento procurado
 * @return true, se o elemento for localizado no arranjo.
 *         false, caso contrário.
 *
 * @post caso a busca seja bem sucedida, pos conterá o índice do
 *       elemento procurado.
 *       Em caso de falha, pos conterá o índice do último elemento
 *       do arranjo.
 */
bool buscaSequencial(int a[], int tam, int alvo, int *pPos);


/**
 * @brief Localiza um elemento alvo em um arranjo ordenado.
 *
 * @param[in]  a    arranjo com dados 
 * @param[in]  tam  número de elementos no arranjo
 * @param[in]  alvo elemento procurado
 * @param[out] pPos endereço onde ficará o índice no arranjo do
 *                  elemento procurado
 * @return true, se o elemento for localizado no arranjo.
 *         false, caso contrário.
 *
 * @post caso a busca seja bem sucedida, pos conterá o índice do
 *       elemento procurado.
 *       Em caso de falha, pos conterá o índice do último elemento
 *       do arranjo.
 */
bool buscaBinaria(int a[], int tam, int alvo, int *pPos);

#endif

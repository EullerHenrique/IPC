/**
 * @file busca.c
 * @brief Implementa a busca sequencial em arranjos não ordenados e a busca
 *        binária para arranjos ordenados.
 *
 * @author Alexsandro Santos Soares
 * @date 6/05/2018
 * @bugs Nenhum conhecido.
 */
#include "busca.h"

/**
 * @brief Localiza um elemento alvo em um arranjo não ordenado.
 *
 * @param[in]  a    arranjo com dados 
 * @param[in]  tam  número de elementos no arranjo
 * @param[in]  alvo elemento procurado
 * @param[out] pPos endereço onde ficará o índice no arranjo do
 *                  elemento procurado
 * @return true, se o elemento for localizado no arranjo.
 *         false, caso contrário.
 *
 * @post caso a busca seja bem sucedida, pos conterá o índice do
 *       elemento procurado.
 *       Em caso de falha, pos conterá o índice do último elemento
 *       do arranjo.
 */
bool buscaSequencial(int a[], int tam, int alvo, int *pPos){
  int i = 0; // índice do arranjo
  bool encontrado = false;

  i = 0;
  while (i < tam && alvo != a[i])
    i++;

  *pPos = i;
  encontrado = (alvo == a[i]);

  return encontrado;
} // buscaSequencial



/**
 * @brief Localiza um elemento alvo em um arranjo ordenado.
 *
 * @param[in]  a    arranjo com dados 
 * @param[in]  tam  número de elementos no arranjo
 * @param[in]  alvo elemento procurado
 * @param[out] pPos endereço onde ficará o índice no arranjo do
 *                  elemento procurado
 * @return true, se o elemento for localizado no arranjo.
 *         false, caso contrário.
 *
 * @post caso a busca seja bem sucedida, pos conterá o índice do
 *       elemento procurado.
 *       Em caso de falha, pos conterá o índice do último elemento
 *       do arranjo.
 */
bool buscaBinaria(int a[], int tam, int alvo, int *pPos){
  int inicio = 0; // índice do inicio da parte analisada
  int meio = 0;   // índice do meio da parte analisada
  int fim = 0   ; // índice do final da parte analisada   
  bool encontrado = false;
  
  inicio = 0;
  fim = tam - 1;
  while (inicio <= fim){
    meio = (inicio + fim) / 2;
    if (alvo > a[meio])
      // Examine a metade superior
      inicio = meio + 1;
    else if (alvo < a[meio])
      // Examine a metade inferior
      fim = meio - 1;
    else
      // Elemento encontrado, forçe a saída
      inicio = fim + 1;
  } // while

  *pPos = meio;
  return alvo == a[meio];
} // buscaBinaria

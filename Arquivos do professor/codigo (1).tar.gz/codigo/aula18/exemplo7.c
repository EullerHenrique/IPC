/**
 * @file exemplo7.c
 * @brief Uso de macros pré-definidas
 *
 * @author Alexsandro Santos Soares
 * @date 6/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){

  printf("\nHoje é %s\n", __DATE__);
  printf("O nome do arquivo é %s\n", __FILE__);
  printf("A linha atual é %d\n", __LINE__);

  if (__STDC__ != 0)
    printf("Este compilador segue o padrão ANSI C\n");
  else
    printf("Este compilador não segue o padrão ANSI C\n");

  printf("Horário atual: %s\n", __TIME__);
  
  return 0;
} // main

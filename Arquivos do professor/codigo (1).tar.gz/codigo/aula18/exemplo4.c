/**
 * @file exemplo3.c
 * @brief Realiza uma busca binária em um arranjo ordenado em ordem crescente.
 *
 * @author Alexsandro Santos Soares
 * @date 6/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <stdbool.h>

/**
 * @brief Localiza um elemento alvo em um arranjo ordenado.
 *
 * @param[in]  a    arranjo com dados 
 * @param[in]  tam  número de elementos no arranjo
 * @param[in]  alvo elemento procurado
 * @param[out] pPos endereço onde ficará o índice no arranjo do
 *                  elemento procurado
 * @return true, se o elemento for localizado no arranjo.
 *         false, caso contrário.
 *
 * @post caso a busca seja bem sucedida, pos conterá o índice do
 *       elemento procurado.
 *       Em caso de falha, pos conterá o índice do último elemento
 *       do arranjo.
 */
bool buscaBinaria(int a[], int tam, int alvo, int *pPos){
  int inicio = 0; // índice do inicio da parte analisada
  int meio = 0;   // índice do meio da parte analisada
  int fim = 0   ; // índice do final da parte analisada   
  bool encontrado = false;
  
  inicio = 0;
  fim = tam - 1;
  while (inicio <= fim){
    meio = (inicio + fim) / 2;
    if (alvo > a[meio])
      // Examine a metade superior
      inicio = meio + 1;
    else if (alvo < a[meio])
      // Examine a metade inferior
      fim = meio - 1;
    else
      // Elemento encontrado, forçe a saída
      inicio = fim + 1;
  } // while

  *pPos = meio;
  return alvo == a[meio];
} // buscaBinaria


int main(void){
  int i = 0;
  int pos = 0;
  int num = 0;
  int a[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

  printf("\nArranjo original ordenado:\n");
  for(i = 0; i < 10; i++)
    printf("%d ",a[i]);
  printf("\n");

  printf("\nDigite o número a ser localizado: ");
  scanf("%d", &num);

  if (buscaBinaria(a, 10, num, &pos))
    printf("%d foi encontrado no índice %d\n", num, pos);
  else
    printf("%d não foi encontrado no arranjo\n", num);
  
  return 0;
} // main

/**
 * @file exemplo5.c
 * @brief Realiza uma busca binária em um arranjo ordenado em ordem crescente.
 *
 * @author Alexsandro Santos Soares
 * @date 6/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <stdbool.h>

#include "busca.h"

int main(void){
  int i = 0;
  int pos = 0;
  int num = 0;
  int a[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

  printf("\nArranjo original ordenado:\n");
  for(i = 0; i < 10; i++)
    printf("%d ",a[i]);
  printf("\n");

  printf("\nDigite o número a ser localizado: ");
  scanf("%d", &num);
  if (buscaBinaria(a, 10, num, &pos))
    printf("%d foi encontrado no índice %d\n", num, pos);
  else
    printf("%d não foi encontrado no arranjo\n", num);  
  return 0;
} // main

/**
 * @file exemplo3.c
 * @brief Realiza uma busca sequencial em um arranjo.
 *
 * @author Alexsandro Santos Soares
 * @date 6/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <stdbool.h>

/**
 * @brief Localiza um elemento alvo em um arranjo não ordenado.
 *
 * @param[in]  a    arranjo com dados 
 * @param[in]  tam  número de elementos no arranjo
 * @param[in]  alvo elemento procurado
 * @param[out] pPos endereço onde ficará o índice no arranjo do
 *                  elemento procurado
 * @return true, se o elemento for localizado no arranjo.
 *         false, caso contrário.
 *
 * @post caso a busca seja bem sucedida, pos conterá o índice do
 *       elemento procurado.
 *       Em caso de falha, pos conterá o índice do último elemento
 *       do arranjo.
 */
bool buscaSequencial(int a[], int tam, int alvo, int *pPos){
  int i = 0; // índice do arranjo
  bool encontrado = false;

  i = 0;
  while (i < tam && alvo != a[i])
    i++;

  *pPos = i;
  encontrado = (alvo == a[i]);

  return encontrado;
} // buscaSequencial


int main(void){
  int i = 0;
  int pos = 0;
  int num = 0;
  int a[10] = { 10, 5, 1, 2, 6, 4, 3, 7, 9, 8};

  printf("\nArranjo original:\n");
  for(i = 0; i < 10; i++)
    printf("%d ",a[i]);
  printf("\n");

  printf("\nDigite o número a ser localizado: ");
  scanf("%d", &num);

  if (buscaSequencial(a, 10, num, &pos))
    printf("%d foi encontrado no índice %d\n", num, pos);
  else
    printf("%d não foi encontrado no arranjo\n", num);
  
  return 0;
} // main

/**
 * @file exemplo15.c
 * @brief Encontra as raízes reais de uma equação de segundo grau
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <math.h>

/**
 * @brief Lê os coeficientes da equação de segundo grau.
 *
 * @param[out] pa coeficiente a
 * @param[out] pb coeficiente b
 * @param[out] pc coeficiente c
 *
 * @post os coeficientes serão modificados
 */
void leiaDados(int *pa, int *pb, int *pc){
  printf("\nDigite os coeficientes a, b e c: ");
  scanf("%d %d %d", pa, pb, pc);
  return;
} // leiaDados

/**
 * @brief Calcula as raízes reais de uma equação de segundo grau
 *
 * @param[in] a coeficiente a
 * @param[in] b coeficiente b
 * @param[in] c coeficiente c
 * @param[out] pRaiz1 primeira raiz
 * @param[out] pRaiz2 segunda raiz
 *
 * @return número de raízes calculadas:
 *          2 - duas raízes reais
 *          1 - raízes idênticas
 *          0 - raízes complexas
 *         -1 - os coeficientes não formam uma equação de grau 2
 *
 * @post as raízes serão modificadas
 */
int quadratico(int a, int b, int c,
               double *pRaiz1, double *pRaiz2){
  int resultado = 0;

  double discriminante = 0.0;
  double raiz = 0.0;

  if (a == 0 && b == 0)
    resultado = -1;
  else if (a == 0) {
      *pRaiz1 = -c / (double) b;
      resultado = 1;
  } // a == 0
  else {
      discriminante = b * b - (4 * a * c);
      if (discriminante >= 0){
         raiz = sqrt(discriminante);
         *pRaiz1 = (-b + raiz) / (2 * a);
         *pRaiz2 = (-b - raiz) / (2 * a);
         resultado = 2;
      } else
         resultado = 0;
  } // else

  return resultado;
} // quadratico


/**
 * @brief Imprime as raízes da equação de segundo grau
 *
 * @param[in] numRaizes número de raízes calculadas
 * @param[in] a coeficiente a
 * @param[in] b coeficiente b
 * @param[in] c coeficiente c
 * @param[in] raiz1 a primeira raiz calculada
 * @param[in] raiz2 a segunda raiz calculada
 */
void imprimeResultados(int numRaizes,
                       int a, int b, int c,
                       double raiz1, double raiz2){
  printf("Sua equação: %dx^2 + %dx + %d\n", a, b, c);

  switch(numRaizes){
  case 2: printf("As raízes são: %6.3f e %6.3f\n", raiz1, raiz2);
          break;
  case 1: printf("A única raiz é: %6.3f\n", raiz1);
          break;
  case 0: printf("As raízes são complexas.\n");
          break;
  default: printf("Os coeficientes são inválidos.\n");
           break;
  } // switch

  return;
} // imprimeResultados

int main(void){
  int a = 0;
  int b = 0;
  int c = 0;
  int numRaizes = 0;
  double raiz1 = 0.0;
  double raiz2 = 0.0;
  char novamente = 'S';

  printf("Resolve equações de segundo grau.\n\n");
  while (novamente == 'S' || novamente == 's'){
    leiaDados(&a, &b, &c);
    numRaizes = quadratico(a, b, c, &raiz1, &raiz2);
    imprimeResultados(numRaizes, a, b, c, raiz1, raiz2);

    printf("\nVocê quer resolver uma outra equação? (S/N) ");
    scanf(" %c", &novamente);
  } // while
  printf("\nAté mais\n\n");

  return 0;
} // main

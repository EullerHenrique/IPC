/**
 * @file exemplo6.c
 * @brief Brincando com variáveis apontadoras.
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
  int a = 0;
  int b = 0;
  int c = 0;
 
  int *p = NULL;
  int *q = NULL;
  int *r = NULL;

  a = 6;
  b = 2;
  p = &b;

  q = p;
  r = &c;

  p = &a;
  *q = 8;

  *r = *p;

  *r = a + *q + *&c;

  printf("a = %d, b = %d, c = %d\n", a, b, c);
  printf("*p = %d, *q = %d, *r = %d\n", *p, *q, *r);
  
  return 0;
} // main

/**
 * @file exemplo5.c
 * @brief Imprimindo com uma variável apontadora.
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
  int a = 0;
  int *pa = NULL;

  a = 14;
  pa = &a;

  printf("endereço armazenado em p:  %p\n", pa);
  printf("valor no endereço apontado por p: %d\n", *pa);
  printf("valor armazenado em a: %d\n\n", a);
  
  return 0;
} // main

/**
 * @file exemplo4.c
 * @brief Acessando variáveis por meio de ponteiros.
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
  int x = 0;
  int *p = NULL;
  int *q = NULL;

  p = &x;
  q = &x; // ambas apontadores recebem o mesmo endereço

  printf("endereço de x: %p\n", &x);
  printf("valor de p:    %p\n", p);
  printf("valor de q:    %p\n\n", q);

  x = 4;
  printf("Primeira atribuição a x ocorreu.\n");
  printf("depois:  x = %d\n" , x);
  printf("depois: *p = %d\n", *p);
  printf("depois: *q = %d\n\n", *q);

  x = x + 3;
  printf("Segunda atribuição a x ocorreu.\n");
  printf("depois:  x = %d\n" , x);
  printf("depois: *p = %d\n", *p);
  printf("depois: *q = %d\n\n", *q);

  *p = 8;
  printf("Atribuição a *p ocorreu.\n");
  printf("depois:  x = %d\n" , x);
  printf("depois: *p = %d\n", *p);
  printf("depois: *q = %d\n\n", *q);
  
  *&x = *q + *p;
  printf("Atribuição a *&x ocorreu.\n");
  printf("depois:  x = %d\n" , x);
  printf("depois: *p = %d\n", *p);
  printf("depois: *q = %d\n\n", *q);

  x = *p * *q;
  printf("Atribuição a x com multiplicação.\n");
  printf("depois:  x = %d\n" , x);
  printf("depois: *p = %d\n", *p);
  printf("depois: *q = %d\n\n", *q);
  
  return 0;
} // main

/**
 * @file exemplo13.c
 * @brief Mostra o tamanho de apontadores e dos objetos por eles referenciados.
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
  char c;
  char *pc;
  int tamanho_de_c      = sizeof(c);
  int tamanho_de_pc     = sizeof(pc);
  int tamanho_de_ast_pc = sizeof(*pc);
  
  int a;
  int *pa;
  int tamanho_de_a      = sizeof(a);
  int tamanho_de_pa     = sizeof(pa);
  int tamanho_de_ast_pa = sizeof(*pa);
  
  double x;
  double *px;
  int tamanho_de_x      = sizeof(x);
  int tamanho_de_px     = sizeof(px);
  int tamanho_de_ast_px = sizeof(*px);

  printf("sizeof(c): %3d | ",  tamanho_de_c);
  printf("sizeof(pc): %3d | ", tamanho_de_pc);
  printf("sizeof(*pc): %3d\n", tamanho_de_ast_pc);

  printf("sizeof(a): %3d | ",  tamanho_de_a);
  printf("sizeof(pa): %3d | ", tamanho_de_pa);
  printf("sizeof(*pa): %3d\n", tamanho_de_ast_pa);

  printf("sizeof(x): %3d | ",  tamanho_de_x);
  printf("sizeof(px): %3d | ", tamanho_de_px);
  printf("sizeof(*px): %3d\n", tamanho_de_ast_px);

  return 0;
} // main

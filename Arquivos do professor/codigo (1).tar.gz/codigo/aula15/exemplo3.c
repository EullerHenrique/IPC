/**
 * @file exemplo3.c
 * @brief Altera o valor de uma variável inteira usando uma apontadora.
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
  int a = 0;
  int *p = NULL;

  printf("antes:  a = %d\n", a);
  a++;
  printf("depois: a = %d\n\n", a);

  a = 0;   // retorna ao valor original

  printf("antes:  a = %d\n", a);
  a = a + 1;
  printf("depois: a = %d\n\n", a);

  a = 0;   // retorna ao valor original
  p = &a;  // coloca o endereço de a em p

  printf("endereço de a: %p\n", &a);
  printf("valor de p:    %p\n\n", p);
  
  printf("antes:  a = %d\n", a);
  *p = *p + 1;
  printf("depois: a = %d\n\n", a);

  a = 0;   // retorna ao valor original
  
  printf("antes:  a = %d\n", a);
  (*p)++;
  printf("depois: a = %d\n\n", a);
  
  return 0;
} // main

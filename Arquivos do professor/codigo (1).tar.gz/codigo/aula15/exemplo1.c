/**
 * @file exemplo1.c
 * @brief Imprime os endereços de memória de variáveis caracter
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
  char a;
  char b;

  printf("endereço de a: %p\n", &a);
  printf("endereço de b: %p\n", &b);  
  return 0;
} // main

/**
 * @file exemplo12.c
 * @brief Mostra como apontadores para apontadores podem ser usados por
 *        diferentes funções scanf para ler dados para a mesma variável.
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
int main(void){
  int a = 0;

  int *p = NULL;
  int **pp = NULL;
  int ***ppp = NULL;

  p   = &a;
  pp  = &p;
  ppp = &pp;

  printf("Digite um número: ");
  scanf("%d", &a);                       // usando a
  printf("Número digitado:  %d\n\n", a);

  printf("Digite um número: ");
  scanf("%d", p);                        // usando p
  printf("Número digitado:  %d\n\n", a);

  printf("Digite um número: ");
  scanf("%d", *pp);                      // usando pp
  printf("Número digitado:  %d\n\n", a);
  
  printf("Digite um número: ");
  scanf("%d", **ppp);                    // usando ppp
  printf("Número digitado:  %d\n\n", a);
  
  return 0;
} // main

/**
 * @file exemplo4.c
 * @brief Lê um número de um arquivo binário e o imprime na tela.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <stdlib.h>

int main(void){
  int num;
  FILE *fp;

  fp = fopen("programa.bin", "rb"); // abre para leitura binária

  if (fp == NULL){
    fprintf(stderr, "Erro na abertura do arquivo programa.bin\n");
    exit(1);
  }

  if (fread(&num, sizeof(int), 1, fp) != 1){
    fprintf(stderr, "Erro de leitura no arquivo programa.bin\n");
    exit(1);
  }

  printf("Valor lido: %d\n", num);
  fclose(fp);
  return 0;
} // main

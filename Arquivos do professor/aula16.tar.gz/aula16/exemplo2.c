/**
 * @file exemplo2.c
 * @brief Lê um número de um arquivo texto e o imprime na tela.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <stdlib.h>

int main(void){
  int num;
  FILE *fp;

  fp = fopen("programa.txt", "r"); // abre para leitura

  if (fp == NULL){
    fprintf(stderr, "Erro na abertura do arquivo programa.txt\n");
    exit(1);
  }

  fscanf(fp, "%d", &num);

  printf("Valor lido: %d\n", num);
  fclose(fp);
  
  return 0;
} // main

/**
 * @file exemplo3.c
 * @brief Lê um número do teclado e o armazena em um arquivo binário.
 *
 * @author Alexsandro Santos Soares
 * @date 5/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <stdlib.h>

int main(void){
  int num;
  FILE *fp;

  fp = fopen("programa.bin", "wb"); // abre para escrita binária

  if (fp == NULL){
    fprintf(stderr, "Erro de escrita no arquivo programa.bin\n");
    exit(1);
  }

  printf("Digite um número: ");
  scanf("%d", &num);

  fwrite(&num, sizeof(int), 1, fp);
  fclose(fp);
  
  return 0;
} // main

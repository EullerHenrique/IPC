/**
 * @file exemplo6.c
 * @brief Imprime o calendário de um determinado mês.
 *
 * @author Alexsandro Santos Soares
 * @date 30/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
void imprimeMes(int primeiroDia, int dias){
    int diaSemana;

    printf("Dom Seg Ter Qua Qui Sex Sab\n");
    printf("--- --- --- --- --- --- ---\n");

    for(diaSemana = 0; diaSemana < primeiroDia; diaSemana++)
        printf("    ");

    for(int diaMes = 1; diaMes <= dias; diaMes++){
        if (diaSemana > 6) {
            printf("\n");
            diaSemana = 1;
        } else
            diaSemana++;
        printf("%3d ", diaMes);
    } // for
    printf("\n--- --- --- --- --- --- ---\n");
    return;
} // imprimeMes

int main(void){
    imprimeMes(5,30); // O primeiro dia do mês caiu na sexta-feira (dia 5)
    return 0;
} // main

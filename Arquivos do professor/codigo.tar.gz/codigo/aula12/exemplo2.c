/**
 * @file exemplo1.c
 * @brief Demonstra o uso de for para imprimir números entre 1 e o número
 *        especificado pelo usuário.
 *
 *
 * @author Alexsandro Santos Soares
 * @date 30/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
    int limite = 0;

    printf("Digite o limite da contagem: ");
    scanf("%d", &limite);
    for (int i = 1; i <= limite; i++)
        printf("\t%d\n", i);
    return 0;
} // main

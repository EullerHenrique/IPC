/**
 * @file exemplo3.c
 * @brief Demonstra o uso de laço for para calcular e mostrar o montante
 *        do capital ano a ano a partir de uma valor inicial e de uma
 *        taxa de juros anual.
 *
 * @author Alexsandro Santos Soares
 * @date 30/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
    double capital=0.0;
    double montante=0.0;
    double taxa=0.0;
    int anos=0;
    int i = 0;

    printf("Entre com o valor inicial: ");
    scanf("%lf", &capital);
    printf("Entre com o taxa de juros anual (nn.n): ");
    scanf("%lf", &taxa);
    printf("Entre com o número de anos: ");
    scanf("%d", &anos);

    printf("\nAno    Valor\n");
    printf("====  ========\n");
    for (montante = capital, i = 1;
         i <= anos;
         i++){
        montante *= 1 + taxa/100.0;
        printf("%3d%11.2lf\n", i, montante);
    } // for

    return 0;
} // main

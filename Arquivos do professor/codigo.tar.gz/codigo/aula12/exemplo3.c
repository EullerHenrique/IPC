/**
 * @file exemplo2.c
 * @brief Demonstra o uso de laços For aninhados para imprimir uma sequência
 *        de números em múltiplas linhas,
 *
 * @author Alexsandro Santos Soares
 * @date 30/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){

    for (int i = 1; i <= 3; i++){
        printf("Linha %d: ", i);
        for (int j = 1; j <= 5; j++)
            printf("%3d", j);
        printf("\n");
    } // for i

    return 0;
} // main

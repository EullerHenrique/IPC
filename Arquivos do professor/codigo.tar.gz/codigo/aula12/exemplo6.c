/**
 * @file exemplo5.c
 * @brief Imprime uma sequência de números na forma de um triângulo
 *        retângulo e completa a linha com asteriscos.
 *
 * @author Alexsandro Santos Soares
 * @date 30/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
    int limite = 0;

    printf("Entre com um número entre 1 e 9: ");
    scanf("%d", &limite);

    for (int linha = 1; linha <= limite; linha++){
        for (int coluna = 1; coluna <= limite; coluna++)
            if (coluna > linha)
                printf("*");
            else
                printf("%1d", coluna);

        printf("\n");
    } // for linha

    return 0;
} // main

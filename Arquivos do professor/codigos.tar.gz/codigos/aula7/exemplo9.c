/**
 * @file exemplo9.c
 * @brief Calcula o fatorial de um número inteiro não negativo.
 *
 *    O programa lê a um número natural n, calculo o fatorial de n
 * e depois o imprime na tela.
 *
 * @author Alexsandro Santos Soares
 * @date 22/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void)
{
  unsigned int n = 0;
  unsigned int i = 0;
  unsigned int fat = 0;

  scanf("%u",  &n);

  i = 0;   // contador de iterações
  fat = 1; // acumula o valor do fatorial
  while (i < n) {
      i = i + 1;
      fat = fat * i;
  } // while
  printf("Fatorial(%u) = %u\n", n, fat);

  return 0;
} // main

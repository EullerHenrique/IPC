/**
 * @file exemplo2.c
 * @brief O algoritmo da divisão inteira.
 * 
 * O programa lerá dois números inteiros, a e b, do teclado e 
 * imprimirá o quociente e o resto inteiros de a divido por b.
 *
 * @author Alexsandro Santos Soares
 * @date 22/04/2018
 * @bugs Se b for zero, haverá um laço infinito
 */
#include <stdio.h>

int main(void)
{
  // Declarações locais
  unsigned int a = 0;
  unsigned int b = 0;
  unsigned int c = 0;

  scanf("%u", &a);
  scanf("%u", &b);
  c = 0;
  
  while (a >= b) {
    a = a - b;
    c = c + 1;
  } // while
  
  printf("%u\n",c);
  printf("%u\n",a);
  return 0;
} // main

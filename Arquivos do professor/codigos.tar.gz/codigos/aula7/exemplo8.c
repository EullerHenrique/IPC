/**
 * @file exemplo8.c
 * @brief Calcula o peso ideal baseado nas fórmulas de Hammond.
 *
 *    O programa lê a altura a em centímetros e o sexo
 * s (um caracter) de uma pessoa e depois calcula e mostra o
 * peso ideal usando as fórmulas de Hammond.
 *
 * @author Alexsandro Santos Soares
 * @date 22/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void)
{
  int a = 0.0;
  char s = ' ';
  float peso = 0.0;

  scanf("%d",  &a);
  scanf(" %c", &s); // descarta todos os brancos após %d, depois lê um char

  if (s == 'm') {
      // Pessoa do sexo masculino
      peso = 48 + 1.1 * (a - 150);
      printf("Peso ideal = %.1f\n", peso);
  } else if (s == 'f') {
      // Pessoa do sexo feminino
      peso = 45 + 0.9 * (a - 150);
      printf("Peso ideal = %.1f\n", peso);
  } else {
      printf("O sexo deve ser indicado por 'm' ou 'f'.\n");
  } // else

  return 0;
} // main

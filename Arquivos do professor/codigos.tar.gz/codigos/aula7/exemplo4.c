/**
 * @file exemplo4.c
 * @brief Verifica se um número natural é par ou ímpar.
 *
 * @author Alexsandro Santos Soares
 * @date 22/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void)
{
  // Declarações locais
  unsigned int n = 0;
  unsigned int r = 0;

  scanf("%u", &n);
  r = n % 2;

  if (r == 0) {
    printf("número é par\n");
  } else {
    printf("número é ímpar\n");
  } // else

  return 0;
} // main

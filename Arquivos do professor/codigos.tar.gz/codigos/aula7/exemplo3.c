/**
 * @file exemplo3.c
 * @brief O algoritmo da divisão inteira.
 *
 * O programa lê números inteiros diferentes de zero e os soma.
 *
 * A condição para o término da leitura é que o usuário digite zero.
 * Nesse caso, o programa imprime na tela o resultado da soma de 
 * todos os inteiros lidos.
 *
 * @author Alexsandro Santos Soares
 * @date 22/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void)
{
  // Declarações locais
  int num = 0;
  int soma = 0;

  soma = 0;
  scanf("%d", &num);
  
  while (num != 0) {
    soma = soma + num;
    scanf("%d", &num);
  } // while
  
  printf("A soma dos números é %d\n",soma);
  return 0;
} // main

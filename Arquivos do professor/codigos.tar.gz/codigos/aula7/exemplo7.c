/**
 * @file exemplo7.c
 * @brief Verifica se três comprimentos formam um triângulo e,
 *        nesse caso, qual triângulo: equilátero, isósceles ou
 *        escaleno.
 *
 *    O programa lê três números em ponto flutuante x, y e z e
 * verifica se eles podem ser os comprimentos dos lados de um
 * triângulo e, neste caso, informa qual tipo de triângulo:
 * equilátero, isósceles ou escaleno. Se os números não formarem
 * um triângulo, escreve a mensagem:
 * "Essas medidas não formam um triângulo".
 *
 * @author Alexsandro Santos Soares
 * @date 22/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void)
{
  // Declarações locais
  float x = 0.0;
  float y = 0.0;
  float z = 0.0;

  scanf("%f", &x);
  scanf("%f", &y);
  scanf("%f", &z);

  if (x < y + z && y < x + z && z < x + y) {
      if (x == y && y == z) {
              printf("Triângulo equilátero\n");
          } else if (x == y || x == z || y == z) {
              printf("Triângulo isósceles\n");
          } else if (x != y && x != z && y != z) {
              printf("Triângulo escaleno\n");
          } // if
  } else {
      printf("Essas medidas não formam um triângulo\n");
  } // else

  return 0;
} // main

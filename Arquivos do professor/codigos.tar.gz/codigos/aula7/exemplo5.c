
/**
 * @file exemplo5.c
 * @brief Encontra as raízes de uma equação de segundo grau.
 *
 *    O programa lê três números em ponto flutuante a, b e c.
 *    O coeficiente a deve ser diferente de zero e, nesse caso,
 * sempre haverá duas raízes reais ou complexas.
 *    Se a for zero, o programa imprime
 * "a deve ser um número real diferente de zero" e termina.
 *    As raízes complexas, se existirem, são impressas no
 * formato x + iy.
 *
 * @author Alexsandro Santos Soares
 * @date 22/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <math.h>

int main(void)
{
  // Declarações locais
  float a = 0.0;
  float b = 0.0;
  float c = 0.0;
  float delta = 0.0;
  float x1 = 0.0;
  float x2 = 0.0;
  float real = 0.0;
  float imag = 0.0;

  scanf("%f", &a);
  if (a == 0) {
    printf("a deve ser um número real diferente de zero\n");
  } else {
    scanf("%f", &b);
    scanf("%f", &c);
    delta = b*b - 4*a*c;
    if (delta >= 0) {
      // As raízes são reais
      x1 = (-b + sqrt(delta)) / (2*a);
      x2 = (-b - sqrt(delta)) / (2*a);
      printf("x1 = %f e x2 = %f\n", x1, x2);
    } else {
      // As raízes são complexas
      real = -b / (2*a);
      imag = sqrt(-delta) / (2*a);
      printf("x1 = %f + i(%f)\n", real, imag);
      printf("x2 = %f - i(%f)\n", real, imag);
    } // else
  } // else

  return 0;
} // main

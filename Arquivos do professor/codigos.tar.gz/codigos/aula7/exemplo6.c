/**
 * @file exemplo6.c
 * @brief Encontra as raízes de uma equação de segundo grau 
 *        usando tipo para números complexos presentes em C11.
 *
 *    O programa lê três números em ponto flutuante a, b e c.
 *    O coeficiente a deve ser diferente de zero e, nesse caso,
 * sempre haverá duas raízes reais ou complexas.
 *    Se a for zero, o programa imprime
 * "a deve ser um número real diferente de zero" e termina.
 *    As raízes complexas, se existirem, são impressas no
 * formato x + iy.
 *
 * @author Alexsandro Santos Soares
 * @date 22/04/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>
#include <complex.h>

int main(void)
{
  // Declarações locais
  float a = 0.0;
  float b = 0.0;
  float c = 0.0;
  float delta = 0.0;
  float complex x1 = 0.0;
  float complex x2 = 0.0;

  scanf("%f", &a);
  if (a == 0) {
    printf("a deve ser um número real diferente de zero\n");
  } else {
    scanf("%f", &b);
    scanf("%f", &c);
    delta = b*b - 4*a*c;

    x1 = (-b + csqrt(delta)) / (2*a);
    x2 = (-b - csqrt(delta)) / (2*a);
    printf("x1 = %.3f + i(%.3f)\n", creal(x1), cimag(x1));
    printf("x2 = %.3f + i(%.3f)\n", creal(x2), cimag(x2));
  } // else

  return 0;
} // main

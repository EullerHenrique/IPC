/**
 * @file exemplo1.c
 * @brief Demonstra alguns dos componentes de um programa C simples.
 *        Esse exemplo é bastante básico.
 * 
 * Neste ponto vai uma explicação mais detalhada do que este módulo
 * se propõe e pode envolver várias linhas.
 *
 * @author Aldovandro Cantagalo (Zé Lindinho)
 * @author Macunaíma
 * @date 21/03/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void)
{
   printf("Alô mundo\n");
   return 0;
} // main

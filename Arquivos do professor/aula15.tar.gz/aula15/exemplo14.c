/**
 * @file exemplo14.c
 * @brief Converte o tempo em segundos para horas, minutos
 *        e segundos.
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

/**
 * @brief Dado o tempo em segundos, o converte em horas, minutos e segundos.
 *
 * @param[in]  tempo  o tempo em segundos
 * @param[out] nCol   número de colunas da matriz
 * @param[out] horas número de horas completas 
 * @param[out] minutos número de minutos completos
 * @param[out] segundos número de segundos completos
 *
 * @return indicador de status: 1 para sucesso e 0 para falha
 * 
 * @post horas, minutos e segundos serão calculados
 */
int segParaHoras (long tempo, int *horas, int *minutos, int *segundos){
  long tempoLocal = 0;

  tempoLocal = tempo;
  *segundos = tempoLocal % 60;
  tempoLocal = tempoLocal / 60;

  *minutos = tempoLocal % 60;

  *horas = tempoLocal / 60;

  if (*horas > 24)
    return 0;
  else
    return 1;
} // segParaHoras

int main(void){
  long tempo = 0;
  int horas = 0;
  int minutos = 0;
  int segundos = 0;

  printf("Digite o tempo em segundos: ");
  scanf("%ld", &tempo);

  if (segParaHoras(tempo, &horas, &minutos, &segundos) == 1){
    printf("%dh %dmin %ds\n", horas, minutos, segundos);
  } else
    printf("A quantidade de horas ultrapassou 24\n");
  
  return 0;
} // main

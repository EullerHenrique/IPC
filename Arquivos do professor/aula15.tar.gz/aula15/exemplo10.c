/**
 * @file exemplo10.c
 * @brief Mostra como usar apontadores diferentes para permutar
 *        o conteúdo de duas variáveis.
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

void permuta(int *px, int *py){
  int temp;

  temp = *px;
  *px = *py;
  *py = temp;
  return;
} // permuta

int main(void){
  int a = 5;
  int b = 7;

  permuta(&a, &b);
  printf("%d %d\n", a, b);
 
  return 0;
} // main

/**
 * @file exemplo8.c
 * @brief Mostra como o mesmo apontador poe apontar para diferentes
 *        variáveis de dados em diferentes comandos.
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
  int a = 0;
  int b = 0;
  int c = 0;
 
  int *p = NULL;

  printf("Digite três números: ");
  scanf("%d %d %d", &a, &b, &c);

  p = &a;
  printf("%3d\n", *p);
  
  p = &b;
  printf("%3d\n", *p);

  p = &c;
  printf("%3d\n", *p);

  return 0;
} // main

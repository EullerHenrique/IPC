/**
 * @file exemplo11.c
 * @brief Mostra como usar apontadores para encontrar o menor dentre
 *        dois números.
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int * menor(int *px, int *py){
  return (*px < *py ? px : py);
} // menor

int main(void){
  int a = 0;
  int b = 0;
  int *p = NULL;

  printf("Digite dois números: ");
  scanf("%d %d", &a, &b);
  
  p = menor(&a, &b);
  
  printf("O menor valor é %d\n", *p); 
  return 0;
} // main

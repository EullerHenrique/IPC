/**
 * @file exemplo7.c
 * @brief Soma dois números usando apontadores.
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
  int a = 0;
  int b = 0;
  int r = 0;
 
  int *pa = &a;
  int *pb = &b;
  int *pr = &r;

  printf("Digite o primeiro número: ");
  scanf("%d", pa);
  printf("Digite o segundo número: ");
  scanf("%d", pb);

  *pr = *pa + *pb;
  printf("\n%d + %d = %d\n", *pa, *pb, *pr);
  
  return 0;
} // main

/**
 * @file exemplo2.c
 * @brief Imprime os endereços de memória de variáveis do tipo int
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
  int a = -123;
  int b = 145;

  printf("a: endereço %p valor %4d\n", &a, a);
  printf("b: endereço %p valor %4d\n", &b, b);  
  return 0;
} // main

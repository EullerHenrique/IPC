/**
 * @file exemplo9.c
 * @brief Mostra como usar apontadores diferentes para apontar para
 *        a mesma variável de dados.
 *
 * @author Alexsandro Santos Soares
 * @date 4/05/2018
 * @bugs Nenhum conhecido.
 */
#include <stdio.h>

int main(void){
  int a = 0;
 
  int *p = NULL;
  int *q = NULL;
  int *r = NULL;

  p = &a;
  q = &a;
  r = &a;
  
  printf("Digite um número: ");
  scanf("%d", &a);

  printf("%d\n", *p);
  printf("%d\n", *q);
  printf("%d\n", *r);
  
  return 0;
} // main
